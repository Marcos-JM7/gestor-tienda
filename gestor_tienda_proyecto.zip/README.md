# Gestor de Productos de Tienda

Proyecto hecho por **Juan Marcos Coca Miranda**.  
Aplicación sencilla para registrar y administrar productos y ventas de una tienda de barrio.

## Tecnologías
- Python
- Streamlit
- SQLite
